import Grids from '../grid/grids.vue'

export default Grids
