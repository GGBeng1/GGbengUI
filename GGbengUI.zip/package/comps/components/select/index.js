import Select from './select.vue'

export default Select
