import Radio from './radio.vue'
import RadioGroup from './radio-group.vue'

Radio.group = RadioGroup
export default Radio
