<template>
  <div class="g__btn--group">
    <slot></slot>    
  </div>
</template>
<script>
export default {
  name: 'g-button-group'
}
</script>

