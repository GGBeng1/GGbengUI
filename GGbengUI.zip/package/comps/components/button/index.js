import Button from './button.vue'

export default Button
