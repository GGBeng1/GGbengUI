import TabbarItem from '../tabbar/tabbar-item.vue'

export default TabbarItem
