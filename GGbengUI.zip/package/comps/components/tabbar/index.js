import TabbarItem from './tabbar-item.vue'
import Tabbar from './tabbar.vue'

Tabbar.item = TabbarItem
export default Tabbar
