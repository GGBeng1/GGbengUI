import Checkbox from './checkbox.vue'
import CheckboxGroup from './checkbox-group.vue'

Checkbox.group = CheckboxGroup
export default Checkbox
