import Navbar from './navbar.vue'

export default Navbar
