import FlexboxItem from '../flexbox/flexbox-item.vue'

export default FlexboxItem
