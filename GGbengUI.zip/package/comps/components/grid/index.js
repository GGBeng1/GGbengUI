import Grid from './grid.vue'
import Grids from './grids.vue'

Grid.group = Grids
export default Grid
