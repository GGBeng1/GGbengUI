import FlexboxItem from './flexbox-item.vue'
import Flexbox from './flexbox.vue'

Flexbox.item = FlexboxItem
export default Flexbox
